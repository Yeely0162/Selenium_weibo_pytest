import pytest
from selenium import webdriver
from ..PageObject.weibo_operations import *
import time

'''
测试用例：验证登录功能
'''

url = "https://weibo.com/login.php"
username = "XXX@163.com"
password = "XXXXXXXXX"


class Test_Login_Weibo(object):
    def setup_method(self):
        self.driver = webdriver.Chrome()
        self.driver.maximize_window()
        self.driver.implicitly_wait(10)
        self.login_op = LoginOper(self.driver)  # 继承查找页面元素的operations
        # self.login_op.__init__(self.driver)  # 传参数driver给operations

    def teardown_method(self):
        self.driver.quit()  # 关闭

    def login_with_cookie(self):
        self.driver.get(url)  # 访问页面
        time.sleep(5)  # 等待页面加载完成
        self.login_op.add_cookies()  # 配置Cookie
        self.driver.refresh()  # 刷新
        time.sleep(15)  # 等待页面加载完成
        assert self.login_op.isLogin()  # 判断是否登录完成的主界面

    @pytest.mark.L1
    def test_01_login(self):
        self.driver.get(url)  # 访问页面
        # ------------登录输入账户和密码-----------
        time.sleep(10)
        # self.login_op.__init__(self.driver)  # 传参数driver给operations
        self.login_op.input_username(username)
        self.login_op.input_password(password)
        # ------------点击登录按钮---------------
        time.sleep(5)  # 等待手动验证码
        self.login_op.click_login_button()
        time.sleep(20)  # 等待登陆页面完全加载完成
        # ------------断言判断是否登录成功--------
        assert self.login_op.isLogin()  # 判断是否登录完成的主界面
        # -------------存储Cookie--------------
        self.login_op.save_cookies()
        self.driver.save_screenshot("./weibo_login" + '.png')

    @pytest.mark.L2
    def test_02_search(self):
        self.login_with_cookie()  # 使用Cookie函数 绕过登录
        self.login_op.search_input('蔡徐坤')  # 发送给搜索框
        self.login_op.search_idol_click()  # 点击该明星/用户
        time.sleep(5)  # 延时截图  等待网页加载完成
        # ------------断言判断是否查询成功--------
        assert self.login_op.is_my_idol() == "蔡徐坤"  # 判断是否成功进入到蔡徐坤主页
        self.driver.save_screenshot("./search_weibo_" + '.png')

    @pytest.mark.L3
    def test_03_send_weibo(self):
        self.login_with_cookie()  # 使用Cookie函数 绕过登录
        self.login_op.send_text('自动化测试\n 测试人:Yeely \n 测试发送!!!') # 输入给发送框
        self.login_op.send_button()  # 点击发送
        time.sleep(1)  # 延时是为了发送成功的弹窗能出来
        # ------------断言判断是否发送成功--------
        assert self.login_op.is_success_send()   # 微博出现发送成功样式来判断是否成功发送
        self.driver.save_screenshot("./test_weibo_send" + '.png')
        time.sleep(2)


if __name__ == '__main__':
    pytest.main(['-s', '-v', '--html=./Report/report_login.html'])
