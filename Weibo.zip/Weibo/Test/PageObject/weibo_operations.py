from ..PageObject.weibo_login import *
import json

filepath = "./cookie.json"


class LoginOper(object):
    def __init__(self, driver):
        self.login_page = LoginPage(driver)

    def input_username(self, username):
        self.login_page.find_login_username().clear()
        self.login_page.find_login_username().send_keys(username)

    def input_password(self, password):
        self.login_page.find_login_password().clear()
        self.login_page.find_login_password().send_keys(password)

    def click_login_button(self):
        self.login_page.find_login_button().click()

    def add_cookies(self):
        fp = open(filepath, 'r')
        cookies = json.load(fp)  # json格式化
        fp.close()
        for cookie in cookies:
            self.login_page.set_cookie(cookie)  # 将字典的Cookie循环输入

    def save_cookies(self):
        cookies = self.login_page.get_cookie()
        fp = open(filepath, 'w')
        json.dump(cookies, fp)  # json格式化
        fp.close()

    def isLogin(self):
        return self.login_page.getAvatar().is_displayed()  # 返回布尔值

    def send_text(self, m):
        self.login_page.send_massage(m)

    def send_button(self):
        self.login_page.send_btn().click()  # 点击发送

    def search_input(self, ms):
        self.login_page.ele_search().send_keys(ms)  # 点击搜索

    def search_idol_click(self):
        self.login_page.search_idol().click()

    def is_my_idol(self):
        return self.login_page.idol().text

    def is_success_send(self):
        return self.login_page.send_success_box().is_displayed()  # 返回布尔值

