from selenium.webdriver.common.by import By
from Weibo.Base.base import *


class LoginPage(object):
    def __init__(self, driver):
        self.driver = driver  # 私有driver

    def find_login_button(self):
        # ele = self.driver.find_element(By.XPATH, '//*[@id="pl_login_form"]/div/div[3]/div[6]/a')  # 获取按钮的ID
        ele = Base(self.driver).get_element('id,pl_login_form')  # 使用base 二次封装Selenium的API
        return ele

    def find_login_username(self):
        # ele = self.driver.find_element(By.ID, 'loginname')  # 根据Name方法 获取用户名的位置
        ele = Base(self.driver).get_element('id,loginname')  # 使用base 二次封装Selenium的API
        return ele

    def find_login_password(self):
        # ele = self.driver.find_element(By.NAME, 'password')  # 根据Name方法 获取密码框的位置
        ele = Base(self.driver).get_element('name,password')  # 使用base 二次封装Selenium的API
        return ele

    def set_cookie(self, cookie):
        self.driver.add_cookie(cookie)

    def get_cookie(self):
        ele = self.driver.get_cookies()
        return ele

    def getAvatar(self):
        ele = self.driver.find_element(By.CLASS_NAME, 'woo-badge-box')
        return ele

    def send_massage(self, massage):
        return self.driver.find_element(By.CLASS_NAME, 'Form_input_2gtXx').send_keys(massage)  # 输入微博内容

    def send_btn(self):
        return self.driver.find_element(By.CLASS_NAME, "Tool_check_2d3ld")

    def ele_search(self):
        return Base(self.driver).get_element('class,woo-input-main')  # 使用base 二次封装Selenium的API

    def idol(self):
        return Base(self.driver).get_element('xpath,//*[@id="app"]/div[2]/div[2]/div[2]/main/div/div/div[2]/div[1]/div[1]/div[2]/div[2]/div[1]/div')

    def send_success_box(self):
        return Base(self.driver).get_element('class,woo-toast-body')


    def search_idol(self):
        return self.driver.find_element(By.XPATH, '//*[@id="app"]/div[2]/div[1]/div/div[1]/div/div/div[1]/div/div[2]/div/div/div/div[2]/div[1]/div/a')